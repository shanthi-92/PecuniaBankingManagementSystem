import { Component, OnInit } from '@angular/core';
import {AccountService ,AccountBean } from '../s-account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-pecunia',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  user: AccountBean = new AccountBean(" "," ",0," "," "," "," ","","","","");
  constructor(private accountService: AccountService,private router: Router) { }
  ngOnInit() {
  }

       createAccount(): void {
        this.accountService.createAccount(this.user).subscribe( data => { alert("Account created Successfully.");});
    
           }
}

