import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';
import{ListComponent}from'./list/list.component';
import{CommonModule}from'@angular/common';
const routes: Routes = [
  {path:'create-pecunia',component:AddComponent},
  {path:'list-pecunia',component:ListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
