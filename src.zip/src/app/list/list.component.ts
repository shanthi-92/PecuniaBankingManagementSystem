import { Component, OnInit } from '@angular/core';
import { AccountService ,AccountBean} from '../s-account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-pecunia',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  users: AccountBean[];
  

  constructor(private accountService:AccountService,private router:Router) { }

  ngOnInit(): void {

    this.accountService.getAll().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response)
  {
      this.users=response;
  }

}
