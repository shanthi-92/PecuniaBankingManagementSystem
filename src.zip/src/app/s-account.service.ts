import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
export class AccountBean
{
  constructor(public accountNumber:string,
    public customerName:string,

    public accountBalance:number,
    public customerAadhar:string,
    public customerContact:string,
    public addressline1:string,
    public addressline2:string,
    public city:string,
    public state:string,
    public country:string,
    public zipcode:string )
    {
    }
}
@Injectable({
  providedIn: 'root'
})
export class AccountService {
  accounts: AccountBean[];
  constructor(private httpService:HttpClient)
  {}
createAccount(account):Observable<AccountBean>
{
  console.log(this.accounts);
  return this.httpService.post<AccountBean>("http://localhost:8092/account/create",account);
}
   getAll(){
        return this.httpService.get<AccountBean[]>("http://localhost:8092/account/findall")
}
}